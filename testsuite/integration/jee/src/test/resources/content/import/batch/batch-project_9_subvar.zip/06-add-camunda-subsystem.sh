#! /bin/bash

##############################################################################
#
# Adds the camunda jboss module as a jboss extension
#
################################################################################
add_camunda_extension() {
	xmlstarlet ed -L -s "//*[local-name()='extensions']" -t elem -n "extension-2" -v ""                                                                                        \
	                 -i "//*[local-name()='extension-2']" -t attr -n "module" -v "org.camunda.bpm.jboss.camunda-jboss-subsystem"                                               \
	                 -r "//*[local-name()='extension-2']" -v "extension" /ericsson/3pp/jboss/standalone/configuration/standalone-enm.xml
}

##############################################################################
#
# Adds the camunda subsytem configuration 
#
################################################################################
add_camunda_subsystem() {
  xmlstarlet ed -L -s "//*[local-name()='profile']" -t elem -n "subsystem-1" -v ""                                                                                             \
                   -i "//*[local-name()='subsystem-1']" -t attr -n "xmlns" -v "urn:org.camunda.bpm.jboss:1.1"                                                                  \
                   -s "//*[local-name()='subsystem-1']" -t elem -n "process-engines-1" -v ""                                                                                   \
                   -s "//*[local-name()='process-engines-1']" -t elem -n "process-engine-1" -v ""                                                                              \
                   -i "//*[local-name()='process-engine-1']" -t attr -n "name" -v "default"                                                                                    \
                   -i "//*[local-name()='process-engine-1']" -t attr -n "default" -v "true"                                                                                    \
                   -s "//*[local-name()='process-engine-1']" -t elem -n "datasource" -v "java:jboss/datasources/ProcessEngine"                                                 \
                   -s "//*[local-name()='process-engine-1']" -t elem -n "history-level" -v "none"                                                                              \
                   -s "//*[local-name()='process-engine-1']" -t elem -n "configuration" -v "org.camunda.bpm.container.impl.jboss.config.ManagedJtaProcessEngineConfiguration"  \
                   -s "//*[local-name()='process-engine-1']" -t elem -n "properties-1" -v ""                                                                                   \
                   -s "//*[local-name()='properties-1']" -t elem -n "property-1-1" -v "default"                                                                                \
                   -i "//*[local-name()='property-1-1']" -t attr -n "name" -v "jobExecutorAcquisitionName"                                                                     \
                   -s "//*[local-name()='properties-1']" -t elem -n "property-1-2" -v "true"                                                                                   \
                   -i "//*[local-name()='property-1-2']" -t attr -n "name" -v "isAutoSchemaUpdate"                                                                             \
                   -s "//*[local-name()='process-engine-1']" -t elem -n "plugins-1" -v ""                                                                                      \
                   -s "//*[local-name()='plugins-1']" -t elem -n "plugin-1" -v ""                                                                                              \
                   -s "//*[local-name()='plugin-1']" -t elem -n "class" -v "org.camunda.bpm.application.impl.event.ProcessApplicationEventListenerPlugin"                      \
                   -s "//*[local-name()='subsystem-1']" -t elem -n "job-executor-1" -v ""                                                                                      \
                   -s "//*[local-name()='job-executor-1']" -t elem -n "thread-pool-name" -v "job-executor-tp"                                                                  \
                   -s "//*[local-name()='job-executor-1']" -t elem -n "job-acquisitions-1" -v ""                                                                               \
                   -s "//*[local-name()='job-acquisitions-1']" -t elem -n "job-acquisition-1" -v ""                                                                            \
                   -s "//*[local-name()='job-acquisition-1']" -t attr -n "name" -v "default"                                                                                   \
                   -s "//*[local-name()='job-acquisition-1']" -t elem -n "acquisition-strategy" -v "SEQUENTIAL"                                                                \
                   -s "//*[local-name()='job-acquisition-1']" -t elem -n "properties-2" -v ""                                                                                  \
                   -s "//*[local-name()='properties-2']" -t elem -n "property-2-1" -v "300000"                                                                                 \
                   -i "//*[local-name()='property-2-1']" -t attr -n "name" -v "lockTimeInMillis"                                                                               \
                   -s "//*[local-name()='properties-2']" -t elem -n "property-2-2" -v "5000"                                                                                   \
                   -i "//*[local-name()='property-2-2']" -t attr -n "name" -v "waitTimeInMillis"                                                                               \
                   -s "//*[local-name()='properties-2']" -t elem -n "property-2-3" -v "3"                                                                                      \
                   -i "//*[local-name()='property-2-3']" -t attr -n "name" -v "maxJobsPerAcquisition"                                                                          \
                   -r "//*[local-name()='subsystem-1']" -v "subsystem"                                                                                                         \
                   -r "//*[local-name()='process-engines-1']" -v "process-engines"                                                                                             \
                   -r "//*[local-name()='process-engine-1']" -v "process-engine"                                                                                               \
                   -r "//*[local-name()='properties-1']" -v "properties"                                                                                                       \
                   -r "//*[local-name()='property-1-1']" -v "property"                                                                                                         \
                   -r "//*[local-name()='property-1-2']" -v "property"                                                                                                         \
                   -r "//*[local-name()='properties-2']" -v "properties"                                                                                                       \
                   -r "//*[local-name()='property-2-1']" -v "property"                                                                                                         \
                   -r "//*[local-name()='property-2-2']" -v "property"                                                                                                         \
                   -r "//*[local-name()='property-2-3']" -v "property"                                                                                                         \
                   -r "//*[local-name()='plugins-1']" -v "plugins"                                                                                                             \
                   -r "//*[local-name()='plugin-1']" -v "plugin"                                                                                                               \
                   -r "//*[local-name()='job-executor-1']" -v "job-executor"                                                                                                   \
                   -r "//*[local-name()='job-acquisitions-1']" -v "job-acquisitions"                                                                                           \
                   -r "//*[local-name()='job-acquisition-1']" -v "job-acquisition" /ericsson/3pp/jboss/standalone/configuration/standalone-enm.xml
}



##############################################################################
#
# Need to find the existing threads subsystem definition 
# (namespace is 'jboss:domain:threads') and add the camunda threadpool configuration.
#
################################################################################
add_camunda_threads() {
   xmlstarlet ed -L -s "//*[local-name() = 'subsystem' and namespace-uri() = 'urn:jboss:domain:threads:1.1']" -t elem -n "bounded-queue-thread-pool-1" -v ""  \
                     -i "//*[local-name()='bounded-queue-thread-pool-1']" -t attr -n "name" -v "job-executor-tp"                 \
                     -i "//*[local-name()='bounded-queue-thread-pool-1']" -t attr -n "allow-core-timeout" -v "true"              \
                     -s "//*[local-name()='bounded-queue-thread-pool-1']" -t elem -n "core-threads-1" -v ""                      \
                     -i "//*[local-name()='core-threads-1']" -t attr -n "count" -v "3"                                           \
                     -s "//*[local-name()='bounded-queue-thread-pool-1']" -t elem -n "queue-length-1" -v ""                      \
                     -i "//*[local-name()='queue-length-1']" -t attr -n "count" -v "3"                                           \
                     -s "//*[local-name()='bounded-queue-thread-pool-1']" -t elem -n "max-threads-1" -v ""                       \
                     -i "//*[local-name()='max-threads-1']" -t attr -n "count" -v "10"                                           \
                     -s "//*[local-name()='bounded-queue-thread-pool-1']" -t elem -n "keepalive-time-1" -v ""                    \
                     -i "//*[local-name()='keepalive-time-1']" -t attr -n "time" -v "10"                                         \
                     -i "//*[local-name()='keepalive-time-1']" -t attr -n "unit" -v "seconds"                                    \
                     -s "//*[local-name() = 'subsystem' and namespace-uri() = 'urn:jboss:domain:threads:1.1']" -t elem -n "blocking-bounded-queue-thread-pool-1" -v ""  \
                     -i "//*[local-name()='blocking-bounded-queue-thread-pool-1']" -t attr -n "name" -v "http-executor"                  \
                     -i "//*[local-name()='blocking-bounded-queue-thread-pool-1']" -t attr -n "allow-core-timeout" -v "true"             \
                     -s "//*[local-name()='blocking-bounded-queue-thread-pool-1']" -t elem -n "core-threads-2" -v ""                     \
                     -i "//*[local-name()='core-threads-2']" -t attr -n "count" -v "5"                                           \
                     -s "//*[local-name()='blocking-bounded-queue-thread-pool-1']" -t elem -n "queue-length-2" -v ""                     \
                     -i "//*[local-name()='queue-length-2']" -t attr -n "count" -v "5"                                           \
                     -s "//*[local-name()='blocking-bounded-queue-thread-pool-1']" -t elem -n "max-threads-2" -v "" %ab                     \
           %          -i "//*[local-name()='max-threads-2']" -t attr -n "count" -v "10"                                           \
                     -s "//*[local-name()='blocking-bounded-queue-thread-pool-1']" -t elem -n "keepalive-time-2" -v ""                   \
                     -i "//*[local-name()='keepalive-time-2']" -t attr -n "time" -v "10"                                         \
                     -i "//*[local-name()='keepalive-time-2']" -t attr -n "unit" -v "seconds"    %abv%                                \
                     -r "//*[local-name()='core-threads-1']" -v "core-threads"                                                   \
                     -r "//*[local-name()='queue-length-1']" -v "queue-length"                                                   \
                     -r "//*[local-name()='max-threads-1']" -v "max-threads"                                                     \
                     -r "//*[local-name()='core-threads-2']" -v "core-threads"                                                   \
                     -r "//*[local-name()='queue-length-2']" -v "queue-length"                                                   \
                     -r "//*[local-name()='max-threads-2']" -v "max-threads"                                                     \
                     -r "//*[local-name()='keepalive-time-1']" -v "keepalive-time"                                               \
                     -r "//*[local-name()='bounded-queue-thread-pool-1']" -v "bounded-queue-thread-pool"                         \
                     -r "//*[local-name()='keepalive-time-2']" -v "keepalive-time"                                               \
                     -r "//*[local-name()='blocking-bounded-queue-thread-pool-1']" -v "blocking-bounded-queue-thread-pool"                       \
                     -r "//*[local-name()='subsystem-1']" -v "subsystem"   /ericsson/3pp/jboss/standalone/configuration/standalone-enm.xml
}


print_title() {
   echo "`date` @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
   echo "`date` $1"
   echo "`date` @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
}

print_title "EXPORTING CAMUNDA SUBSYSTEM TO SERVICE-ENM.XML"
add_camunda_extension
add_camunda_subsystem
add_camunda_threads